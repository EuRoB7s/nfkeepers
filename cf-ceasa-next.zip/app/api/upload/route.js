import { put } from '@vercel/blob';

export const runtime = 'edge';
export const revalidate = 0;

export async function POST(req) {
  const form = await req.formData();
  const file = form.get('arquivo');
  if (!file) return Response.json({ erro: 'Arquivo ausente.' }, { status: 400 });

  const safeName = String(file.name || 'arquivo').replace(/\s+/g, '_');
  const pathname = `uploads/${Date.now()}-${safeName}`;

  const { url } = await put(pathname, file, {
    access: 'public',
    contentType: file.type || 'application/octet-stream'
  });

  return Response.json({ arquivoUrl: url });
}
