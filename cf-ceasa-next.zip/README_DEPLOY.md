# C&F Ceasa — Next.js + Vercel Blob

## Como publicar (100% online)
1. Crie um repositório no GitHub e envie estes arquivos.
2. Na Vercel: **Add New Project** → importe o repositório.
3. No Dashboard da Vercel: **Storage → Blobs → Connect** e selecione este projeto.
4. Deploy. Pronto.

## Rotas
- `POST /api/upload` — recebe campo `arquivo` (FormData); salva no Blob e retorna `{ arquivoUrl }`
- `POST /api/notas` — body JSON `{ numero, data, arquivoUrl }`; salva JSON em `notas/{numero}/{data}.json`
- `GET /api/notas/:numero?data=YYYY-MM-DD` — retorna JSON salvo

## Observações
- É necessário conectar o **Vercel Blob** para leitura/escrita.
- Node 22.x (já declarado em `package.json`).
