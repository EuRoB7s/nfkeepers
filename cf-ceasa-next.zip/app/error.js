'use client';

export default function Error({ error, reset }) {
  return (
    <div style={{padding:16}}>
      <h2>Ops, algo quebrou.</h2>
      <pre style={{whiteSpace:'pre-wrap'}}>{String(error)}</pre>
      <button onClick={() => reset()}>Tentar novamente</button>
    </div>
  );
}
