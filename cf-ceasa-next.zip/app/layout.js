export const metadata = {
  title: 'C&F Ceasa',
  description: 'Envio e busca de notas'
};

import './globals.css';

export default function RootLayout({ children }) {
  return (
    <html lang="pt-br">
      <body>{children}</body>
    </html>
  );
}
