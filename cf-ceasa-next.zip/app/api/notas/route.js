import { put } from '@vercel/blob';

export const runtime = 'edge';
export const revalidate = 0;

export async function POST(req) {
  const { numero, data, arquivoUrl } = await req.json().catch(() => ({}));
  if (!numero || !data || !arquivoUrl) {
    return Response.json({ erro: 'numero, data e arquivoUrl são obrigatórios.' }, { status: 400 });
  }

  const pathname = `notas/${encodeURIComponent(numero)}/${encodeURIComponent(data)}.json`;
  const payload = { numero, data, arquivoUrl, savedAt: new Date().toISOString() };

  await put(pathname, JSON.stringify(payload), {
    access: 'public',
    contentType: 'application/json; charset=utf-8'
  });

  return Response.json({ ok: true });
}
