import { list } from '@vercel/blob';

export const runtime = 'edge';
export const revalidate = 0;

export async function GET(req, { params }) {
  const numero = params.numero;
  const data = new URL(req.url).searchParams.get('data');
  if (!data) return Response.json({ erro: 'data é obrigatória.' }, { status: 400 });

  const pathname = `notas/${encodeURIComponent(numero)}/${encodeURIComponent(data)}.json`;
  const { blobs } = await list({ prefix: pathname, limit: 1 });
  if (!blobs?.length) return Response.json({ erro: 'Nota não encontrada.' }, { status: 404 });

  const r = await fetch(blobs[0].url);
  const nota = await r.json();
  return Response.json(nota);
}
