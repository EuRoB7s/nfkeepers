'use client';
import { useState } from 'react';

export default function Home() {
  const [numero, setNumero] = useState('');
  const [data, setData] = useState('');
  const [arquivo, setArquivo] = useState(null);
  const [msg, setMsg] = useState('');
  const [resultado, setResultado] = useState(null);
  const [loading, setLoading] = useState(false);

  async function enviar(e){
    e.preventDefault();
    setMsg(''); setResultado(null);
    if(!numero || !data || !arquivo){ setMsg('Preencha número, data e selecione um arquivo.'); return; }
    try{
      setLoading(true);
      const form = new FormData();
      form.append('arquivo', arquivo);
      const u = await fetch('/api/upload', { method:'POST', body: form });
      const up = await u.json();
      if (!u.ok) throw new Error(up?.erro || 'Falha no upload');

      const r = await fetch('/api/notas', {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ numero, data, arquivoUrl: up.arquivoUrl })
      });
      const jr = await r.json();
      if(!r.ok) throw new Error(jr?.erro || 'Falha ao salvar nota');

      setMsg('Nota enviada com sucesso!');
      setResultado({ numero, data, arquivoUrl: up.arquivoUrl });
    }catch(err){
      setMsg('Erro ao enviar: ' + err.message);
    }finally{
      setLoading(false);
    }
  }

  async function buscar(e){
    e.preventDefault();
    setMsg(''); setResultado(null);
    if(!numero || !data){ setMsg('Informe número e data.'); return; }
    try{
      setLoading(true);
      const r = await fetch(`/api/notas/${encodeURIComponent(numero)}?data=${encodeURIComponent(data)}`);
      const jr = await r.json();
      if(!r.ok) throw new Error(jr?.erro || 'Falha na busca');
      setResultado(jr);
      setMsg('Nota encontrada!');
    }catch(err){
      setMsg('Erro na busca: ' + err.message);
    }finally{
      setLoading(false);
    }
  }

  return (
    <div className="wrap">
      <h1>C&amp;F Ceasa — Next.js</h1>

      <form className="card" onSubmit={enviar}>
        <h2>Enviar Nota</h2>
        <label>Número da Nota
          <input value={numero} onChange={e=>setNumero(e.target.value)} placeholder="ex: 123" />
        </label>
        <label>Data
          <input type="date" value={data} onChange={e=>setData(e.target.value)} />
        </label>
        <label>Arquivo (PDF/JPG/PNG)
          <input type="file" onChange={e=>setArquivo(e.target.files?.[0]||null)} />
        </label>
        <button type="submit" disabled={loading}>{loading ? 'Enviando...' : 'Enviar'}</button>
      </form>

      <form className="card" onSubmit={buscar}>
        <h2>Buscar Nota</h2>
        <label>Número da Nota
          <input value={numero} onChange={e=>setNumero(e.target.value)} placeholder="ex: 123" />
        </label>
        <label>Data
          <input type="date" value={data} onChange={e=>setData(e.target.value)} />
        </label>
        <button type="submit" disabled={loading}>{loading ? 'Buscando...' : 'Buscar'}</button>
      </form>

      {msg && <div className="msg">{msg}</div>}

      {resultado && (
        <div className="card">
          <h3>Resultado</h3>
          <div><b>Número:</b> {resultado.numero}</div>
          <div><b>Data:</b> {resultado.data}</div>
          {resultado.arquivoUrl && <div>
            <a href={resultado.arquivoUrl} target="_blank" rel="noreferrer">Abrir arquivo</a>
          </div>}
        </div>
      )}
    </div>
  );
}
